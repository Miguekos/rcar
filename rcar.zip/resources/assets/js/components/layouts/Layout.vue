<template>
<div class="">
  <v-app>
  <v-navigation-drawer app></v-navigation-drawer>
  <v-toolbar app></v-toolbar>
  <v-content>
  <v-container fluid>

  </v-container>
  </v-content>
  <v-footer app></v-footer>
  </v-app>
</div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
