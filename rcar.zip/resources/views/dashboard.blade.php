@extends('layouts.app')

@section('content')
<div>
    <comp-dashboard></comp-dashboard>
</div>
@endsection