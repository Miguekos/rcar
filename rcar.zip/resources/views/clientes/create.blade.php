@extends('layouts.app')

@section('content')
    <cliente-create></cliente-create>
@endsection
